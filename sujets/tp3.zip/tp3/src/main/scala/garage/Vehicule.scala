package garage

trait Vehicule {

  def rouler():Unit = println("roule")

}
