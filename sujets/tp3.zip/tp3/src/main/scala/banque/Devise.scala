package banque

object devise {

  class DeviseEuro(val montant:Int)
  class DeviseUsa(val montant:Int)
}

