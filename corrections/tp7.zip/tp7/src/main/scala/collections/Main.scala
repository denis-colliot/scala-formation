package collections


object Main extends App {

  println(CollectionRepository.getBigText().split(" ").size)

}
